import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './Components/welcome/welcome.component';
import { CarComponent } from './Components/car/car.component';
import { LoginComponent } from './Components/login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { AdminpanelComponent } from './Components/adminpanel/adminpanel.component';
import { UserpanelComponent } from './Components/userpanel/userpanel.component';
import { AdmincarComponent } from './Components/admincar/admincar.component';
import { AdminbookingsComponent } from './Components/adminbookings/adminbookings.component';
import { AdminprofileComponent } from './Components/adminprofile/adminprofile.component';
import { AdminaccountsComponent } from './Components/adminaccounts/adminaccounts.component';
import { ForgotpasswordComponent } from './Components/forgotpassword/forgotpassword.component';
import { UserbookingComponent } from './Components/userbooking/userbooking.component';
import { UsercarsComponent } from './Components/usercars/usercars.component';
import { UserprofileComponent } from './Components/userprofile/userprofile.component';
import { UpdatecarComponent } from './Components/updatecar/updatecar.component';
import { BookcarComponent } from './Components/bookcar/bookcar.component';
import { PaymentComponent } from './Components/payment/payment.component';
import { RouterguardService } from './Services/routerguard.service';
import { NewpaymentComponent } from './Components/newpayment/newpayment.component';
import { LowpriceComponent } from './Components/userpanel/lowprice/lowprice.component';
import { HighpriceComponent } from './Components/userpanel/highprice/highprice.component';

const routes: Routes = [{path:"",component:WelcomeComponent},
  {path:"addcar",component:CarComponent,canActivate:[RouterguardService]},
  {path:"loginurl",component:LoginComponent},
  {path:"registerurl",component:RegisterComponent},
  {path:"adminurl",component:AdminpanelComponent,canActivate:[RouterguardService]},
  {path:"userurl",component:UserpanelComponent,canActivate:[RouterguardService]},
  {path:"welcomeurl",component:LoginComponent},
  {path:"admincar",component:AdmincarComponent,canActivate:[RouterguardService]},
  {path:"adminbookings",component:AdminbookingsComponent,canActivate:[RouterguardService]},
  {path:"adminprofile",component:AdminprofileComponent,canActivate:[RouterguardService]},
  {path:"adminaccounts",component:AdminaccountsComponent,canActivate:[RouterguardService]},
  {path:"forgotpass/:usermail",component:ForgotpasswordComponent},
  {path:"userbookings",component:UserbookingComponent,canActivate:[RouterguardService]},
  {path:"usercars",component:UsercarsComponent,canActivate:[RouterguardService]},
  {path:"userprofile",component:UserprofileComponent,canActivate:[RouterguardService]},
  {path:"updatecarurl/:carId",component:UpdatecarComponent,canActivate:[RouterguardService]},
  {path:"bookcar/:carId",component:BookcarComponent,canActivate:[RouterguardService]},
  {path:"paymenturl",component:PaymentComponent,canActivate:[RouterguardService]},
  {path:"newpaymenturl/:bookingId/:carId",component:NewpaymentComponent,canActivate:[RouterguardService]},
  {path:"welcomeurl",component:WelcomeComponent},
  {path:'lowcarpriceurl',component:LowpriceComponent},
  {path:'highcarpriceurl',component:HighpriceComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
