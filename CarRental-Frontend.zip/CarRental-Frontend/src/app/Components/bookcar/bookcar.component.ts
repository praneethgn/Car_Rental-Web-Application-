import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from '../../Services/car.service';
import { BookingService } from '../../Services/booking.service';
import { Booking } from '../../model/Booking';

@Component({
  selector: 'app-bookcar',
  standalone: false,
  templateUrl: './bookcar.component.html',
  styleUrls: ['./bookcar.component.css']
})
export class BookcarComponent implements OnInit {

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private carService: CarService,
    private bookingService: BookingService
  ) {}

  userId:any;
  carId: any;
  bookingId:any;
  booking = new Booking();
  car: any;
  dateError: boolean = false;
  minDate: string="";  // Minimum start date

  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId')
    console.log(this.userId)
    this.carId = this.activatedRoute.snapshot.params['carId'];
    this.carService.getCarById(this.carId).subscribe(
      (response: any) => {
        this.car = response;
      }
    );

    // Set the minimum date for the start date to today's date
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0]; // Get the date in YYYY-MM-DD format
  }

  // Handle change in start date
  onStartDateChange() {
    if (this.booking.startDate) {
      // Recalculate total cost when the start date is changed
      this.calculateTotalCost();
    }
  }

  // Calculate total cost based on start and end date
  calculateTotalCost() {
    if (this.booking.startDate && this.booking.endDate && this.car?.rentalPrice) {
      const start = new Date(this.booking.startDate);
      const end = new Date(this.booking.endDate);
      const timeDiff = end.getTime() - start.getTime();
      const days = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;

      // Check for valid date range
      if (days <= 0) {
        this.booking.totalCost = 0;
        this.dateError = true;
      } else {
        this.dateError = false;
        this.booking.totalCost = days * this.car.rentalPrice;
      }
    }
  }

  // Submit the booking if valid
  submitBooking() {
    if (this.dateError) {
      alert("Please choose a valid end date.");
      return;
    }
    this.bookingService.addBooking(this.booking,this.carId,this.userId).subscribe(
      (response:any)=>{
        this.bookingId=response.bookingId
        console.log(response)
        /*this.carService.updateCarAvailability(this.carId,"Not Available").subscribe(
          (response:any)=>{
            console.log(response)
            this.car=response
          }
        )*/
        console.log("Pay Now")
        this.router.navigate(['newpaymenturl',this.bookingId,this.carId])
      }
    )
  }
}
