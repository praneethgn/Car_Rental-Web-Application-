import { Component, OnInit } from '@angular/core';
import { CarService } from '../../Services/car.service';
import { Router } from '@angular/router';
import { Car } from '../../model/Car';
import { AdminService } from '../../Services/admin.service';
import { Subject, debounceTime, switchMap, of } from 'rxjs';

@Component({
  selector: 'app-car',
  standalone: false,
  templateUrl: './car.component.html',
  styleUrl: './car.component.css'
})
export class CarComponent implements OnInit {

  car: Car = new Car();
  carNoExists: boolean = false;
  imagePreviewUrl: string | ArrayBuffer | null = null;

  private carNoInput$ = new Subject<string>();

  constructor(
    private carService: CarService,
    private router: Router,
    private adminService: AdminService
  ) {}

  ngOnInit(): void {
    this.carNoInput$.pipe(
      debounceTime(500),
      switchMap(carNo => {
        const trimmed = carNo.trim().replace(/\s+/g, '');
        if (!trimmed || !/^[A-Za-z]{2}\d{2}[A-Za-z]{2}\d{4}$/.test(trimmed)) {
          return of(null);
        }
        return this.adminService.findCarNo(trimmed);
      })
    ).subscribe(response => {
      this.carNoExists = response !== null && response !== undefined;
    });
  }

  // Called on (input) event of car number field
  onCarNoInput(carNo: string): void {
    this.carNoInput$.next(carNo);
  }

  addCar(): void {
    // Remove spaces in carNo before submitting
    this.car.carNo = this.car.carNo.replace(/\s+/g, '');
    
    this.carService.addCar(this.car).subscribe(
      (response: any) => {
        console.log(response);
        alert("Car added Successfully");
        this.router.navigate(['admincar']);
      }
    );
  }

  previewImage(): void {
    this.imagePreviewUrl = this.car.carLink || null;
  }
}