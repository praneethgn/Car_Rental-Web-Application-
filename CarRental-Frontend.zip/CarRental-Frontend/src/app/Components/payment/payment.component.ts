import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../../Services/payment.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BankServer } from '../../model/BankServer';
import { Payment } from '../../model/Payment';
import { BookingService } from '../../Services/booking.service';


@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit{

  constructor(private activatedRoute:ActivatedRoute,private paymentService:PaymentService,private router:Router,
    private fb:FormBuilder,
    private bookingService:BookingService
  ){}

  userId:any;
  bookingId:any;
  carId:any;
  payment=new Payment();
  paymentForm!:FormGroup;
  bankserver=new BankServer();
  paymentButton:boolean=false;
  booking:any;

  ngOnInit(): void {
     /* this.bookingId=this.activatedRoute.snapshot.params['bookingId']
      this.carId=this.activatedRoute.snapshot.params['carId']
      this.bookingService.getBooking(this.bookingId).subscribe(
        (response:any)=>{
          this.booking=response
        }
      )
      console.log(this.booking)
      this.payment.paymentAmount=this.booking.totalCost;*/
      this.activatedRoute.queryParams.subscribe(params=>{
        this.payment.paymentAmount=params['totalcost']?parseFloat(params['totalcost']):0;
        this.bookingId=params['bookingId'];
        this.carId=params['carId'];
      });
  }

 // Simple Card Number Validation (Only 16 digits)
cardNumberValidator(control: any) {
  const num = control.value.replace(/\s/g, '');
  return /^\d{16}$/.test(num) ? null : { invalidCard: true };
}

// Expiry Date Validation (MM/YY)
expiryDateValidator(control: any) {
  const regex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
  if (!regex.test(control.value)) return { invalidExpiryDate: true };

  const [month, year] = control.value.split('/').map(Number);
  const currentYear = new Date().getFullYear() % 100;
  const currentMonth = new Date().getMonth() + 1;

  if (year < currentYear || (year === currentYear && month < currentMonth)) {
    return { expiredCard: true };
  }
  return null;
}

// Auto-format card number (Adds space every 4 digits)
formatCardNumber() {
  let num = this.paymentForm.get('cardNumber')?.value;
  num = num.replace(/\D/g, '');
  num = num.replace(/(\d{4})/g, '$1 ').trim();
  this.paymentForm.get('cardNumber')?.setValue(num, { emitEvent: false });
}


submitPayment() {
  if (this.paymentForm.invalid) {
    alert("Please fill in all required fields correctly!");
    return;
  }

   // Assign form values to `this.payment` before submitting
   this.payment = {
    cardholderName: this.paymentForm.value.cardholderName,
    //cardNumber: this.paymentForm.value.cardNumber.replace(/\s/g, ''), // Remove spaces
    //exipireDate: this.paymentForm.value.expiryDate,
    //cvv: this.paymentForm.value.cvv,
    paymentAmount: this.payment.paymentAmount,
    paymentStatus: 'Success', // Default status before successful transaction
    paymentDate: new Date(), // Automatically set the payment date
    paymentId:this.paymentForm.value.paymentId

  };

  //console.log('Submitting payment:', this.payment);
  //console.log('UserId:', this.userId, 'BookingId:', this.bookingId);
  this.bankserver.cCardnumber=this.paymentForm.value.cardNumber.replace(/\s/g, '')
  this.bankserver.cCvvnumber=this.paymentForm.value.cvv
  this.bankserver.cCardholdername=this.payment.cardholderName;
  this.bankserver.expiryDate=this.paymentForm.value.expiryDate;

  console.log('expiry date',this.bankserver.expiryDate);
  console.log(this.bankserver);

  this.paymentService.getBankServer(this.bankserver).subscribe(
    (response:any)=>{
      if(response!=null){
        //console.log('111111111111111');
        //alert("Invalid Card Details!!")
        this.paymentButton=true;
        
      }
      else{
        //console.log('2222222222222222');
        //this.paymentButton=true;
        alert("Invalid Card Details!!")
      }
    });
if(this.paymentButton){
  //Now call the payment service with the updated `this.payment`
  this.paymentService.addPayment(this.payment,this.bookingId).subscribe(
    (response: any) => {
      alert("Payment Done Successfully")
    }
  );
}else{
  //console.log('3333333333333333');
  // alert("invalid card details");
  //this.router.navigate(['/paymenturl']);
}
}

}
