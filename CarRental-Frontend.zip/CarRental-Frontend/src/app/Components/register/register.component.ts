import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../Services/login.service';
import { User } from '../../model/User';
import { AuthenticationService } from '../../Services/authentication.service';
import { debounceTime, of, Subject, switchMap } from 'rxjs';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user = new User();
  confirmPassword: string = '';
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;

  emailExists = false;
  phoneExists = false;
  dlExists = false;

  private emailInput$ = new Subject<string>();
  private phoneInput$ = new Subject<string>();
  private dlInput$ = new Subject<string>();

  constructor(private router: Router, private loginService: LoginService, private authenticationService: AuthenticationService) {
    // Setup debounced validators
    this.emailInput$.pipe(
      debounceTime(500),
      switchMap(email => this.authenticationService.checkEmail(email))
    ).subscribe((response: any) => {
      this.emailExists = !!response;
    });

    this.phoneInput$.pipe(
      debounceTime(500),
      switchMap(phone => {
        if (!phone || phone.length !== 10) {
          return of(null); // Don't check for empty/invalid
        }
        return this.authenticationService.checkPhoneNumber(phone);
      })
    ).subscribe((response: any) => {
      console.log('Phone check response:', response); // Optional debugging
      this.phoneExists = !!response;
    });

    this.dlInput$.pipe(
      debounceTime(500),
      switchMap(dl => {
        const phone = this.user.phoneNumber?.trim();
        if (!phone || !dl?.trim()) return of(null); // Prevent empty checks
        return this.authenticationService.validateDlAndPhone(dl.trim(), phone);
      })
    ).subscribe((response: any) => {
      // Assume `true` means match found, `false` means not found
      this.dlExists = !response;
    });
  }

  onEmailChange(email: string) {
    this.emailInput$.next(email);
  }

  onPhoneChange(phone: string) {
    phone = phone.trim();
    this.user.phoneNumber = phone;

    this.phoneExists = false; // Reset on every change
    if (phone.length === 10 && /^[6-9]\d{9}$/.test(phone)) {
      this.phoneInput$.next(phone);
    }

    // Trigger DL check too (if DL input is not empty)
    if (this.user.drivingLicense?.trim()) {
      this.dlInput$.next(this.user.drivingLicense.trim());
    }
  }

  onDlChange(dl: string) {
    this.dlInput$.next(dl);
  }

  togglePassword() {
    const passwordInput = document.getElementById('pass') as HTMLInputElement;
    this.showPassword = !this.showPassword;
    passwordInput.type = this.showPassword ? 'text' : 'password';
  }

  toggleConfirmPassword() {
    const confirmPasswordInput = document.getElementById('cpass') as HTMLInputElement;
    this.showConfirmPassword = !this.showConfirmPassword;
    confirmPasswordInput.type = this.showConfirmPassword ? 'text' : 'password';
  }

  registerUser() {
    if (this.user.password !== this.confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    if (this.emailExists || this.phoneExists || this.dlExists) {
      alert("Please fix the errors before submitting.");
      return;
    }

    this.loginService.addUser(this.user).subscribe((finalResponse: any) => {
      if (finalResponse != null) {
        alert("Register Successful");
        alert("Login Now");
        this.router.navigate(['login']);
      } else {
        alert("Registration Failed");
        this.router.navigate(['register']);
      }
    });
  }

  isFormValid(form: any): boolean {
    return form.valid &&
      this.user.password === this.confirmPassword &&
      !this.emailExists &&
      !this.phoneExists &&
      !this.dlExists;
  }

}
