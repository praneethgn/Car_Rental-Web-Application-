import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../Services/login.service';
import { User } from '../../model/User';
import { debounceTime, of, Subject, switchMap } from 'rxjs';
import { AuthenticationService } from '../../Services/authentication.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  user = new User();
  getUser = new User();
  userId: any;
  showPassword = false;
  emailExists = false;

  private emailInput$ = new Subject<string>();

  constructor(
    private router: Router,
    private loginService: LoginService,
    private authenticationService: AuthenticationService
  ) {
    this.emailInput$.pipe(
      debounceTime(500),
      switchMap(email => {
        if (!email || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{3,}$/.test(email)) {
          return of(false);
        }
        return this.authenticationService.checkEmail(email);
      })
    ).subscribe((response: any) => {
      this.emailExists = !!response;
    });
  }

  onEmailChange(email: string) {
    this.emailInput$.next(email.trim());
  }

  togglePasswordVisibility() {
    const passwordInput = document.getElementById('lpass') as HTMLInputElement;
    this.showPassword = !this.showPassword;
    passwordInput.type = this.showPassword ? 'text' : 'password';
  }

  loginUser() {
    if (!this.emailExists) {
      alert("This email does not exist. Please register first.");
      return;
    }

    this.loginService.login(this.user).subscribe((response: any) => {
      if (response) {
        this.getUser = response;
        this.userId = this.getUser.userId;
        sessionStorage.setItem('userId', this.userId);

        if (response.role === "Admin") {
          alert("Admin Login Successful");
          this.router.navigate(['adminurl']);
        } else if (response.role === "User") {
          alert("User Login Successful");
          this.router.navigate(['userurl']);
        } else {
          alert("Login Failed");
          this.router.navigate(['loginurl']);
        }
      } else {
        alert("Login Failed");
      }
    });
  }

  forgotpass() {
    if (!this.emailExists) {
      alert("Enter a registered email first.");
      return;
    }
    this.router.navigate(['forgotpass', this.user.email]);
  }

}
