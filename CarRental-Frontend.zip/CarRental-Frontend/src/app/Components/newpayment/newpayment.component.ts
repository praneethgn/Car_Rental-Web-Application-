import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from '../../Services/payment.service';
import { BookingService } from '../../Services/booking.service';
import { Payment } from '../../model/Payment';
import { BankServer } from '../../model/BankServer';
import { Booking } from '../../model/Booking';
import { CarService } from '../../Services/car.service';
import { Car } from '../../model/Car';

@Component({
  selector: 'app-newpayment',
  standalone: false,
  templateUrl: './newpayment.component.html',
  styleUrl: './newpayment.component.css'
})
export class NewpaymentComponent implements OnInit {

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private paymentService: PaymentService,
    private bookingService: BookingService,
    private carService: CarService
  ) {}

  bookingId: any;
  carId: any;

  payment: Payment = new Payment();
  bankserver: BankServer = new BankServer();
  booking: Booking = new Booking();
  car: Car = new Car();

  paymentSuccess = false;
  paymentError = false;
  isProcessing = false;

  cardExists = true;
  expiryInvalid = false;

  ngOnInit(): void {
    this.bookingId = this.activatedRoute.snapshot.params['bookingId'];
    this.carId = this.activatedRoute.snapshot.params['carId'];

    this.bookingService.getBooking(this.bookingId).subscribe((response: any) => {
      this.booking = response;
      this.payment.paymentAmount = this.booking.totalCost;
    });
  }

  formatCardNumber(): void {
    let digitsOnly = this.bankserver.cCardnumber.replace(/\D/g, '').slice(0, 16);
    console.log("Comming Here 1")
    this.bankserver.cCardnumber = digitsOnly.replace(/(.{4})/g, '$1 ').trim();
    console.log(digitsOnly)
    const rawCard = digitsOnly;
    if (rawCard.length === 16) {
      console.log("Comming Here 2")
    this.paymentService.checkCardNumber(rawCard).subscribe({
      next: (res: BankServer) => {
        // If the BankServer object is returned and it contains a valid response
        if (res && res.cCardnumber) {
          this.cardExists = true;  // The card exists
        } else {
          this.cardExists = false; // Card does not exist or invalid
        }
      },
      error: () => {
        this.cardExists = false;  // In case of error (e.g., card not found)
      }
    });
    } else {
      this.cardExists = false;
    }
  }

  onExpiryInput(): void {
    let raw = this.bankserver.expiryDate.replace(/\D/g, '').slice(0, 4);
    if (raw.length > 2) raw = raw.slice(0, 2) + '/' + raw.slice(2);
    this.bankserver.expiryDate = raw;

    const [monthStr, yearStr] = raw.split('/');
    const month = +monthStr;
    const year = +yearStr;
    const today = new Date();
    const currentYear = today.getFullYear() % 100;
    const currentMonth = today.getMonth() + 1;

    if (month < 1 || month > 12 || isNaN(year) || isNaN(month)) {
      this.expiryInvalid = true;
    } else if (year < currentYear || (year === currentYear && month < currentMonth)) {
      this.expiryInvalid = true;
    } else {
      this.expiryInvalid = false;
    }
  }

  onSubmit(): void {
    this.isProcessing = true;
  this.paymentError = false;
  this.paymentSuccess = false;

  const rawCardNumber = this.bankserver.cCardnumber.replace(/\D/g, '');

  const validationPayload = {
    cCardnumber: rawCardNumber,
    cCvvnumber: this.bankserver.cCvvnumber,
    expiryDate: this.bankserver.expiryDate,
    cCardholdername: this.bankserver.cCardholdername
  };

  this.paymentService.getBankServer(validationPayload).subscribe(
    (response:any)=>{
      if(response!=null){
        this.cardExists = true;
        this.payment.cardholderName = this.bankserver.cCardholdername;
        this.payment.paymentStatus = "Success";

        this.paymentService.addPayment(this.payment,this.bookingId).subscribe(
          (response:any)=>{
            if(response!=null){
              this.paymentSuccess = true;
            this.isProcessing = false;
            alert("Payment Successful!");

            this.carService.updateCarAvailability(this.carId, "Not Available").subscribe((response: any) => {
              this.car = response;
            });

            this.router.navigate(['userbookings']);
            }else{
            alert("Payment Failed")
            this.paymentError = true;
            this.isProcessing = false;
            }
          }
        )

      }else{
        //this.cardExists = false;
        this.paymentError = true;
        this.isProcessing = false;
      }
    }
  )

 /* this.paymentService.getBankServer(validationPayload).subscribe({
    next: (res: BankServer) => {
      // ❗ Validate full card info returned from backend
      if (
        res &&
        res.cCardnumber &&
        res.cCvvnumber === this.bankserver.cCvvnumber &&
        res.expiryDate === this.bankserver.expiryDate &&
        res.cCardholdername === this.bankserver.cCardholdername
      ) {
        this.cardExists = true;

        this.payment.cardholderName = this.bankserver.cCardholdername;
        this.payment.paymentStatus = "Success";

        this.paymentService.addPayment(this.payment, this.bookingId).subscribe({
          next: () => {
            this.paymentSuccess = true;
            this.isProcessing = false;
            alert("Payment Successful!");

            this.carService.updateCarAvailability(this.carId, "Not Available").subscribe((response: any) => {
              this.car = response;
            });

            this.router.navigate(['userbookings']);
          },
          error: (err) => {
            console.error('Payment saving failed:', err);
            this.paymentError = true;
            this.isProcessing = false;
          }
        });
      } else {
        // ❌ Invalid card info
        this.cardExists = false;
        this.paymentError = true;
        this.isProcessing = false;
      }
    },
    error: (err) => {
      console.error('Bank validation failed:', err);
      this.cardExists = false;
      this.paymentError = true;
      this.isProcessing = false;
    }
  });*/
  }
}
