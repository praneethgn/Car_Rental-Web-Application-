import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { Router } from '@angular/router';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-userprofile',
  standalone: false,
  templateUrl: './userprofile.component.html',
  styleUrl: './userprofile.component.css'
})
export class UserprofileComponent implements OnInit{

  user=new User();
  userId:any;

  constructor(private router:Router,private adminService:AdminService){}

  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId')
     this.adminService.getUserById(this.userId).subscribe(
      (response:any)=>{
        this.user=response
      }
     )
  }

  onUpdate(){
    this.adminService.updateUser(this.user,this.userId).subscribe(
      (response:any)=>{
        alert("Updated Successfully")
        this.user=response
        this.router.navigate(['userurl'])
      }
    )
  }

  onLogout(){
    sessionStorage.removeItem('userId')
    alert("Logout Successfull")
    this.router.navigate(['loginurl'])
  }

}
