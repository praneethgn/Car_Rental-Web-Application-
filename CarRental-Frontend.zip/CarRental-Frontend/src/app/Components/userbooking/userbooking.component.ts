import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userbooking',
  standalone: false,
  templateUrl: './userbooking.component.html',
  styleUrl: './userbooking.component.css'
})
export class UserbookingComponent implements OnInit{
  constructor(private userService:UserService,private router:Router){}

 // bookings:any[]=[];
 bookings:any;
  userId:any;
  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId')
    console.log(this.userId);
    this.userService.getBookingByUserId(this.userId).subscribe(
      (response:any)=>{
        console.log(response);
        this.bookings=response;
      })
    /*this.userService.getBookingByUserId(this.userId).subscribe(
      (response:any)=>{
        for (let booking of response) {
          if (booking.car !== null) {
            this.bookings.push(booking);
          }
        }
        console.log(this.userId)
        console.log(response)
        //this.bookings=response
      }
    )*/
  }

    /*fetch(){
    this.userService.getBookingByUserId(this.userId).subscribe(
      (response:any)=>{
        for (let booking of response) {
          if (booking.car !== null) {
            this.bookings.push(booking);
          }
        }
        console.log(this.userId)
        console.log(response)
        //this.bookings=response
      }
    )
    
  }*/

}
