import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CarService } from '../../Services/car.service';

@Component({
  selector: 'app-updatecar',
  standalone: false,
  templateUrl: './updatecar.component.html',
  styleUrl: './updatecar.component.css'
})
export class UpdatecarComponent implements OnInit{

  constructor(private activeRoute:ActivatedRoute,private router:Router,private carService:CarService){}

  carId:any;
  car:any;
  ngOnInit(): void {
      //this.carId=sessionStorage.getItem('carId')
      this.carId=this.activeRoute.snapshot.params['carId'];
      this.carService.getCarById(this.carId).subscribe(
        (response:any)=>{
          this.car=response
        }
      )
  }

  updateCar(){
    this.carService.updateCarById(this.carId,this.car).subscribe(
      (response:any)=>{
        alert("Car Updated Successfully")
        this.router.navigate(['admincar'])
      }
    )
  }

}
