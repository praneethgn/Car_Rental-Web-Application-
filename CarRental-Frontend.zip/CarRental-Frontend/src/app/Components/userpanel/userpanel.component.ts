import { Component, OnInit,ViewChild, ElementRef } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { Router } from '@angular/router';
import { User } from '../../model/User';
import { CarService } from '../../Services/car.service';

@Component({
  selector: 'app-userpanel',
  standalone: false,
  templateUrl: './userpanel.component.html',
  styleUrl: './userpanel.component.css'
})
export class UserpanelComponent implements OnInit{

  constructor(private userService:UserService,private router:Router,private carService:CarService){}

  userId:any;
  user=new User();
  cars:any;
  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId');
    this.carService.getAvailableCar().subscribe(
      (response:any)=>{
        this.cars=response
      }
    )
    /*this.userService.getUserById(this.userId).subscribe(
      (response:any)=>{
        console.log(response)
        this.user=response;
      }
    )*/
  }

  logout(){
    sessionStorage.removeItem('userId');
    this.router.navigate(['welcomeurl'])
  }

  bookCar(carId:any){
    this.router.navigate(['bookcar',carId])
  }

  //foter scroll
  @ViewChild('footerRef') footerRef!: ElementRef;
  scrollToFooter() {
    this.footerRef.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  @ViewChild('sectionRef') sectionRef!: ElementRef;

scrollToSection() {
  this.sectionRef.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

@ViewChild('headerRef') headerRef!: ElementRef;
scrollToHeader() {
  this.headerRef.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

  

}
