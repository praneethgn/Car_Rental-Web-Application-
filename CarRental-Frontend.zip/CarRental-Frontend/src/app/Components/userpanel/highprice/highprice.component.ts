import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../../Services/user.service';
import { CarService } from '../../../Services/car.service';
import { BookingService } from '../../../Services/booking.service';
import { AdminService } from '../../../Services/admin.service';
import { User } from '../../../model/User';

@Component({
  selector: 'app-highprice',
  standalone: false,
  templateUrl: './highprice.component.html',
  styleUrl: './highprice.component.css'
})
export class HighpriceComponent implements OnInit {

  constructor(private router:Router, private userService:UserService, private carService:CarService,
    private bookingService:BookingService, private adminService:AdminService
  ){}

  userId:any;
  user = new User();
  bookings:any[] = [];
  cars:any[] = [];          // All cars
  filteredCars:any[] = [];  // Cars to display based on filter
  todayDate:string = "";

  ngOnInit(): void {
    this.userId = sessionStorage.getItem('userId');

    this.adminService.getAllBooking().subscribe(
      (response:any) => {
        for (let booking of response) {
          if (booking.car !== null) {
            const today = new Date();
            this.todayDate = today.toISOString().split('T')[0];
            if (booking.endDate < this.todayDate) {
              this.carService.updateCarAvailability(booking.car.carId, "Available").subscribe();
            } else {
              this.carService.updateCarAvailability(booking.car.carId, "Not Available").subscribe();
            }
          }
        }
      }
    )

    this.carService.getAvailableCar().subscribe(
      (response: any) => {
        this.cars = response;
        // ⭐ Filter cars with rentalPrice less than 4000
        this.filteredCars = this.cars.filter(car => car.rentalPrice > 4000);
      }
    );
  }

  bookCar(carId:any) {
    this.router.navigate(['bookcar', carId])
  }

  filterCars(fuelType:string) {
    if (fuelType === 'All') {
      this.filteredCars = this.cars;
    } else {
      this.filteredCars = this.cars.filter(car => 
        car.fuelType.toLowerCase() === fuelType.toLowerCase()
      );
    }
  }

}