import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LowpriceComponent } from './lowprice.component';

describe('LowpriceComponent', () => {
  let component: LowpriceComponent;
  let fixture: ComponentFixture<LowpriceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LowpriceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LowpriceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
