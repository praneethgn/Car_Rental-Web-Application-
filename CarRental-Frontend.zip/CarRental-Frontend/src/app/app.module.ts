import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './Components/welcome/welcome.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CarComponent } from './Components/car/car.component';
import { LoginComponent } from './Components/login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { UserpanelComponent } from './Components/userpanel/userpanel.component';
import { AdminpanelComponent } from './Components/adminpanel/adminpanel.component';
import { AdmincarComponent } from './Components/admincar/admincar.component';
import { AdminbookingsComponent } from './Components/adminbookings/adminbookings.component';
import { AdminprofileComponent } from './Components/adminprofile/adminprofile.component';
import { AdminaccountsComponent } from './Components/adminaccounts/adminaccounts.component';
import { ForgotpasswordComponent } from './Components/forgotpassword/forgotpassword.component';
import { UserbookingComponent } from './Components/userbooking/userbooking.component';
import { UsercarsComponent } from './Components/usercars/usercars.component';
import { UserprofileComponent } from './Components/userprofile/userprofile.component';
import { UpdatecarComponent } from './Components/updatecar/updatecar.component';
import { BookcarComponent } from './Components/bookcar/bookcar.component';
import { PaymentComponent } from './Components/payment/payment.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { NewpaymentComponent } from './Components/newpayment/newpayment.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { LowpriceComponent } from './Components/userpanel/lowprice/lowprice.component';
import { HighpriceComponent } from './Components/userpanel/highprice/highprice.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    CarComponent,
    LoginComponent,
    RegisterComponent,
    UserpanelComponent,
    AdminpanelComponent,
    AdmincarComponent,
    AdminbookingsComponent,
    AdminprofileComponent,
    AdminaccountsComponent,
    ForgotpasswordComponent,
    UserbookingComponent,
    UsercarsComponent,
    UserprofileComponent,
    UpdatecarComponent,
    BookcarComponent,
    PaymentComponent,
    NewpaymentComponent,
    LowpriceComponent,
    HighpriceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    SlickCarouselModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
