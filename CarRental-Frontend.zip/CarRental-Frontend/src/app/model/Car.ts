export class Car{
    carId:any;
    brand:any;
    name:any;
    carLink:any;
    year:number|null;
    seat:number|null;
    mileage:any;
    rentalPrice:any;
    availability:any;
    carNo:any;
    fuelType:any;

    constructor(){
        this.brand="";
        this.name="";
        this.carLink="";
        this.year=null;
        this.seat=null;
        this.mileage=null;
        this.rentalPrice=null;
        this.availability="Available";
        this.carNo="";
        this.fuelType="";
    }

}