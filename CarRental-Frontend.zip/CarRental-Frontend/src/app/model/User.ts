export class User{

    userId:any;
    firstName:string;
    lastName:string;
    phoneNumber:any;
    email:string;
    address:string;
    password:string;
    drivingLicense:string;
    role:string;
    favourite:string;

    constructor(){
        this.firstName="";
        this.lastName="";
        this.phoneNumber="";
        this.email="";
        this.address="";
        this.password="";
        this.drivingLicense="";
        this.role="User";
        this.favourite="";
    }

}