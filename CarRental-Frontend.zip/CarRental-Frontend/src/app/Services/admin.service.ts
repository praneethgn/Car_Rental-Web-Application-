import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private httpClient:HttpClient) { }

  url="http://localhost:8030/api/users"
  bookingUrl="http://localhost:8030/api/bookings"
  carUrl="http://localhost:8030/api/cars"

  getAllByUserRole(){
    return this.httpClient.get(`${this.url}/userrole`)
  }

  deleteUserById(userId:any){
    return this.httpClient.delete(`${this.url}/deleteUser/${userId}`)
  }

  getAllBooking(){
    return this.httpClient.get(`${this.bookingUrl}`)
  }

  getUserById(userId:any){
    return this.httpClient.get(`${this.url}/getUserById/${userId}`)
  }

  updateUser(user:any,userId:any){
    return this.httpClient.put(`${this.url}/${userId}`,user)
  }

  findCarNo(carNo:any){
    return this.httpClient.get(`${this.carUrl}/findCarNo/${carNo}`)
  }

}
