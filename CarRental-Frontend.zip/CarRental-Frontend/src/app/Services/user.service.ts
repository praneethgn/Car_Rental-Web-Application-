import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

  user=new User();

  url="http://localhost:8030/api/users"
  bookingUrl="http://localhost:8030/api/bookings"
  getUserById(userId:any){
    console.log(userId)
    return this.httpClient.get(`${this.url}/getUserById/${userId}`)
  }

  getBookingByUserId(userId:any){
    return this.httpClient.get(`${this.bookingUrl}/getBookingByUserId/${userId}`)
  }

  forgotpass(usermail:string){
    return this.httpClient.get(`${this.url}/findbyemail/${usermail}`)
  }

  updatePassword(usermail:any,password:any){
    return this.httpClient.put(`${this.url}/updatepass/${usermail}/${password}`,this.user)
  }
}
