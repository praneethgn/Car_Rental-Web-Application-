import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BankServer } from '../model/BankServer';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private httpClient:HttpClient) { }

  url="http://localhost:8030/api/payments"
  bankUrl="http://localhost:8030/api/bankserver"

  getBankServer(bankserver:any):Observable<BankServer>
  {
    return this.httpClient.post<BankServer>(`${this.bankUrl}/validation`,bankserver);
  }

  addPayment(payment:any,bookingId:any){
    return this.httpClient.post(`${this.url}/${bookingId}`,payment)
  }
  
  checkCardNumber(cardNumber: any): Observable<BankServer> {
    console.log("comming here")
    return this.httpClient.get<BankServer>(`${this.bankUrl}/findbycardnumber/${cardNumber}`)
  }
}
