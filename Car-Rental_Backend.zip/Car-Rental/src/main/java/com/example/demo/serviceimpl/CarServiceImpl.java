package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Booking;
import com.example.demo.model.Car;
import com.example.demo.repository.BookingRepository;
import com.example.demo.repository.CarRepository;
import com.example.demo.service.CarService;

@Service
public class CarServiceImpl implements CarService{

	@Autowired 
	private CarRepository carRepository;
	
	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public List<Car> getAllCar() {
		// TODO Auto-generated method stub
		return carRepository.findAll();
	}

	@Override
	public Car addCar(Car car) {
		// TODO Auto-generated method stub
		return carRepository.save(car);
	}

	@Override
	public Car getCarById(Long carId) {
		// TODO Auto-generated method stub
		return carRepository.findById(carId).get();
	}

	@Override
	public List<Car> deleteCarById(Long carId) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		Car car=getCarById(carId);
		List<Booking> bookingList=car.getBookings();
		for(Booking booking:bookingList) {
			booking.setCar(null);
			bookingRepository.save(booking);
		}
		carRepository.deleteById(car.getCarId());
		return getAllCar();
	}

	@Override
	public Car updateCar(Long carId, Car car) {
		// TODO Auto-generated method stub
		Car existingCar=getCarById(carId);
		//existingCar.setYear(car.getYear());
		existingCar.setMileage(car.getMileage());
		existingCar.setCarLink(car.getCarLink());
		existingCar.setRentalPrice(car.getRentalPrice());
		existingCar.setAvailability(car.getAvailability());
		return carRepository.save(existingCar);
	}

	@Override
	public List<Car> getCarsByAvailability() {
		// TODO Auto-generated method stub
		return carRepository.findAllByAvailability();
	}

	@Override
	public Car updateCarAvailability(Long carId,String availability) throws ExceptionFound {
		// TODO Auto-generated method stub
		Car existingCar=getCarById(carId);
		existingCar.setAvailability(availability);
		return carRepository.save(existingCar);
	}

	@Override
	public Car findCarNo(String carNo) {
		// TODO Auto-generated method stub
		return carRepository.findByCarNo(carNo);
	}

	/*@Override
	public Car getCarByBookingId(Long bookingId) {
		// TODO Auto-generated method stub
		return carRepository.findByBookingBookingId(bookingId);
	}*/
	
}
