package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Car;
import com.example.demo.service.CarService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/cars")
public class CarController {
	
	@Autowired
	private CarService carService;
	
	@PostMapping
	public Car addCar(@RequestBody Car car) {
		
		return carService.addCar(car);
	}
	
	@GetMapping
	public List<Car> getAllCar() throws ExceptionFound{
		return carService.getAllCar();
	}
	
	@GetMapping("/getCarById/{carId}")
	public Car getCarById(@PathVariable Long carId) {
		return carService.getCarById(carId);
	}

	@DeleteMapping("/deleteCarById/{carId}")
	public List<Car> deleteCarById(@PathVariable Long carId){
		return carService.deleteCarById(carId);
	}
	
	@PutMapping("/updateCarById/{carId}")
	public Car updateCarById(@PathVariable Long carId,@RequestBody Car car) throws ExceptionFound {
		return carService.updateCar(carId, car);
	}
	
	@GetMapping("/getCarByAvailability")
	public List<Car> getCarByAvailability(){
		return carService.getCarsByAvailability();
	}
	
	/*@GetMapping("/getCarByBookingId/{bookingId}")
	public Car getCarByBookingId(@PathVariable Long bookingId) {
		return carService.getCarByBookingId(bookingId);
	}*/
	
	@PutMapping("/updateCarAvailability/{carId}/{availability}")
	public Car updateCarAvailability(@PathVariable Long carId,@PathVariable String availability) throws ExceptionFound {
		return carService.updateCarAvailability(carId,availability);
	}
	
	@GetMapping("/findCarNo/{carno}")
	public Car findCarNo(@PathVariable("carno") String carno) {
		//System.out.println("Hello");
		Car car=carService.findCarNo(carno);
		//System.out.println("Hello");
		return car;
	}
}
