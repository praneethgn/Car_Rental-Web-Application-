package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Booking;
import com.example.demo.model.Car;
import com.example.demo.model.Payment;
import com.example.demo.model.User;
import com.example.demo.repository.BookingRepository;
import com.example.demo.service.BookingService;
import com.example.demo.service.CarService;
import com.example.demo.service.PaymentService;
import com.example.demo.service.UserService;

@Service
public class BookingServiceImpl implements BookingService{
	
	@Autowired
	BookingRepository bookingRepository;

	@Autowired
	UserService userService;
	
	@Autowired
	CarService carService;
	
	//@Autowired
	//PaymentService paymentService;
	
	@Override
	public Booking addBooking1(Booking booking) {
		// TODO Auto-generated method stub
		return bookingRepository.save(booking);
	}

	@Override
	public List<Booking> getAllBooking() {
		// TODO Auto-generated method stub
		return bookingRepository.findAll();
	}

	@Override
	public Booking getBookingById(Long bookingId) {
		// TODO Auto-generated method stub
		return bookingRepository.findById(bookingId).get();
	}

	@Override
	public List<Booking> getBookingByUserId(Long userId) {
		// TODO Auto-generated method stub
		return bookingRepository.findByUserUserId(userId);
	}
	
	@Override
	public List<Booking> getBookingByCarId(Long carId) {
		// TODO Auto-generated method stub
		return bookingRepository.findByCarCarId(carId);
	}

	@Override
	public List<Booking> deleteBookingById(Long bookingId) {
		// TODO Auto-generated method stub
		Booking booking=getBookingById(bookingId);
		bookingRepository.deleteById(booking.getBookingId());
		return getAllBooking();
	}

	@Override
	public Booking updateBookingById(Long bookingId,Booking booking) {
		// TODO Auto-generated method stub
		Booking existingBooking=getBookingById(bookingId);
		existingBooking.setStartDate(booking.getStartDate());
		existingBooking.setEndDate(booking.getEndDate());
		return bookingRepository.save(existingBooking);
	}


	@Override
	public Booking addBooking(Booking booking, Long userId, Long carId) {
		// TODO Auto-generated method stub
		User user=userService.getUserById(userId);
		Car car=carService.getCarById(carId);
		//Payment payment=paymentService.getPaymentById(paymentId);
		booking.setUser(user);
		booking.setCar(car);
		//booking.setPayment(payment);
		return bookingRepository.save(booking);
	}

	@Override
	public Long getCarByBookingId(Long bookingId) {
		// TODO Auto-generated method stub
		return bookingRepository.findCarByBookingId(bookingId);
	}

	

}
