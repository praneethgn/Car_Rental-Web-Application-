package com.example.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.BankServer;
import com.example.demo.repository.BankServerRepository;
import com.example.demo.service.BankServerService;

@Service
public class BankServerServiceImpl implements BankServerService{

	@Autowired
	private BankServerRepository bankServerRepository;
	
	@Override
	public BankServer saveDetails(BankServer bankServer) {
		// TODO Auto-generated method stub
		return bankServerRepository.save(bankServer);
	}

	@Override
	public BankServer findByCardCvv(Long cCardnumber, Integer cCvvnumber, String expiryDate) {
		// TODO Auto-generated method stub
		return bankServerRepository.findByCardCvv(cCardnumber, cCvvnumber, expiryDate);
	}

	@Override
	public BankServer findByUpi(String cUpi) {
		// TODO Auto-generated method stub
		return bankServerRepository.findByUpi(cUpi);
	}

	@Override
	public BankServer cardValidation(BankServer bankServer) {
		// TODO Auto-generated method stub
		
		return bankServerRepository.cardValidation(bankServer.getcCardnumber(), bankServer.getcCvvnumber(), bankServer.getExpiryDate(), bankServer.getcCardholdername());
	}

	@Override
	public BankServer findCardNumber(Long cCardnumber) {
		// TODO Auto-generated method stub
		return bankServerRepository.findByCCardnumber(cCardnumber);
	}

}
