package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.DrivingLicense;

public interface DrivingLicenseRepository extends JpaRepository<DrivingLicense,Long>{

	public DrivingLicense findByDrivingLicenseNoAndPhoneNumber(String drivingLicenseNo,String phoneNumbe);
}
