package com.example.demo.repository;

import java.util.List;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Booking;
import com.example.demo.model.Car;

public interface BookingRepository extends JpaRepository<Booking,Long>{

	public List<Booking> findByUserUserId(Long userId);
	public List<Booking> findByCarCarId(Long carId);
	
	@Query(value = "select car_id from booking where booking_id = ?1", nativeQuery = true)
	Long findCarByBookingId(Long bookingId);

	
	//@Query(value = "select  b.car from  booking b where b.bookingId =?1",nativeQuery = true)
	//public Car findCarByBookingId(Long bookingId);
}
