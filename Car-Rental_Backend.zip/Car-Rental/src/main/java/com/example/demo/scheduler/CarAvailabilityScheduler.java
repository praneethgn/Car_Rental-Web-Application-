package com.example.demo.scheduler;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Booking;
import com.example.demo.model.Car;
import com.example.demo.repository.CarRepository;
import com.example.demo.service.BookingService;

@Component
public class CarAvailabilityScheduler {

    /*@Autowired
    private BookingService bookingService;

    @Autowired
    private CarRepository carRepository;

    // Runs every day at midnight
    @Scheduled(cron = "0 * * * * ?")
    public void updateCarAvailability() throws ExceptionFound {
        LocalDate today = LocalDate.now();
        List<Booking> bookings = bookingService.getAllBooking();

        for (Booking booking : bookings) {
            Car car = booking.getCar();

            if (car != null && booking.getEndDate() != null) {
                LocalDate endDate = convertToLocalDate(booking.getEndDate());

                if (endDate.isBefore(today)) {
                    if (!"Available".equalsIgnoreCase(car.getAvailability())) {
                        car.setAvailability("Available");
                        carRepository.save(car); // update the car availability
                    }
                }
            }
        }
    }

    // Utility method to convert Date to LocalDate
    private LocalDate convertToLocalDate(Date date) {
        return date.toInstant()
                   .atZone(ZoneId.systemDefault())
                   .toLocalDate();
    }*/
}
