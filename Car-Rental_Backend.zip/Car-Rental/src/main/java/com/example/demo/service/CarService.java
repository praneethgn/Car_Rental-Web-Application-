package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Car;
public interface CarService {

	public List<Car> getAllCar() throws ExceptionFound;
	public Car addCar(Car car);
	public Car getCarById(Long carId);
	public List<Car> deleteCarById(Long carId);
	public Car  updateCar(Long carId,Car car) throws ExceptionFound;
	public List<Car> getCarsByAvailability();
	public Car  updateCarAvailability(Long carId,String availability) throws ExceptionFound;
	public Car findCarNo(String carNo);
}
