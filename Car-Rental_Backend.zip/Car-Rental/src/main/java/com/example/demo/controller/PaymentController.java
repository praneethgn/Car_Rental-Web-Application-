package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Payment;
import com.example.demo.service.PaymentService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/payments")
public class PaymentController {

	@Autowired
	private PaymentService paymentService;
	
	@PostMapping
	public Payment addPayment1(@RequestBody Payment payment) {
		return paymentService.addPayment1(payment);
	}
	
	@PostMapping("{bookingId}")
	public Payment addPayment(@RequestBody Payment payment,@PathVariable Long bookingId) {
		return paymentService.addPayment(payment,bookingId);
	}
	
	@GetMapping
	public List<Payment> getAllPayment() throws ExceptionFound{
		return paymentService.getAllPayment();
	}
	
	@GetMapping("/getPaymentById/{paymentId}")
	public Payment getPaymentById(@PathVariable Long paymentId){
		return paymentService.getPaymentById(paymentId);
	}
	
	@DeleteMapping("/deletePaymentById/{paymentId}")
	public List<Payment> deletePaymentById(@PathVariable Long paymentId){
		return paymentService.deletePayment(paymentId);
	}
	
	@PutMapping("/updatePaymentById/{paymentId}")
	public Payment updatePaymentById(@PathVariable Long paymentId,@RequestBody Payment payment) throws ExceptionFound {
		return paymentService.updatePaymentById(paymentId, payment);
	}
	
	@GetMapping("/getPaymentByBookingId/{bookingId}")
	public Payment getPaymentByBookingId(@PathVariable Long bookingId) {
		return paymentService.getPaymentByBookingId(bookingId);
	}
}
